Få de sjove Kaomoji, Japanske tekst-smilier, direkte som et tastatur på din iPhone og iPad!

(ﾉ◕ヮ◕)ﾉ*:･ﾟ  ∑(O_O；)   (ﾟДﾟ≡ﾟДﾟ)?   ~(ø_ø。)   （*＾3＾）/～

Du kan indsætte kaomoji i enhver app med dette tastatur for iOS 8. Udtryk enhver følelse med en af de glade, sure, sørgmodige og frække indbyggede kaomoji, eller lav din helt egen ved at kombinere mund, øjne og arme, for at få dit helt personlige udtryk!

Kaomoji tastaturet kommer med en app, hvor du kan prøve tastaturet, men hvis du installerer det som et systemtastatur, kan du indsætte kaomoji i envher app, f.eks. SMS og Messenger. Du kan markere dine favoritter, og så holder den styr på hvilke du sidst har brugt, så at de altid er lige ved hånden.

ヾ（*⌒ヮ⌒*）ゞ   (#･益･)  ヽ（´ー｀）  ｡･ﾟﾟ･(>д<)･ﾟﾟ･｡  (@ω@)

Med hundredevis af kaomoji kan du hurtigt sende en sjov meddelelse til dine venner, og når du laver dine egne kan du kombinere dele til at lave bogstaveligt talt millioner af forskellige tekst-ansigter, i ethvert humør. Hvis du kan lide iPhonen’s indbyggede emoji-tastatur, så vil du helt sikkert også kunne lide Kaomoji Tastatur!
