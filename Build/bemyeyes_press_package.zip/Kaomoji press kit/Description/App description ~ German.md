Hol dir die lustigen japanischen Kaomoji text emoticons direkt als Tastatur auf dein iPhone, iPod oder iPad!

(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧  (╯°□°）╯︵ ┻━┻   (ﾟДﾟ≡ﾟДﾟ)?   (´°̥̥̥̥̥̥̥̥ω°̥̥̥̥̥̥̥̥｀)   （*＾3＾）/～❤

Mit dieser Tastatur für iOS8 kannst du Kaomoji in jeder App verwenden. Verleihe deinen Gefühlen Ausdruck mit Hilfe der glücklichen, traurigen, bösen und flirtenden Kaomoji. Oder entwerfe deine eigenen Kaomoji durch kombinieren von vorgegebenen Mündern, Augen und Armen und entwerfe deine eigenen Emotions-ausdrücke!

Die kaomoji Tastatur kommt mit einer eigenen App mit der du die Tastatur testen kannst. Installierst du es dann als Systemtatatur, steht es dir auch in allen anderen Apps zur Verfügung, wie z.B SMS oder Messenger. Für super schnellen Zugriff auf deine favorisierten und kürzlich benutzen Kaomoji stehen dir extra tabs zur Verfügung. Mit hunderten Emotionen und Ausdrücken kannst du schnell und einfach Nachrichten an deine Freunde senden und Sie mit deiner Vielfältigkeit beeindrucken. 

ヾ（*⌒ヮ⌒*）ゞ   (╬ಠ益ಠ)  ヽ（´ー｀）┌  ｡･ﾟﾟ･(>д<)･ﾟﾟ･｡  (ʃƪ ˘ ³˘)

Solltest du von emojis schon begeistert sein, wirst du die noch vielseitigeren Kaomojis mit sicherheit lieben!