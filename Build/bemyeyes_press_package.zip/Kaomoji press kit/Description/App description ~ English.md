Get the fun Kaomoji, Japanese text emoticons, directly as a keyboard on your iPhone and iPad!

(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧  (╯°□°）╯︵ ┻━┻   (ﾟДﾟ≡ﾟДﾟ)?   (´°̥̥̥̥̥̥̥̥ω°̥̥̥̥̥̥̥̥｀)   （*＾3＾）/～❤

You can type kaomoji into any app with this keyboard for iOS8. Express any emotion with any of the happy, angry, sad and flirty bundled kaomoji, or make your own by combining mouth, eyes and arms to get your own unique expression!

The kaomoji Keyboard app comes with an app, where you can try out the keyboard, but if you install it as a system keyboard, you can make Kaomoji in any app, such as the SMS and Messenger app. It also allows you to mark your favorites, and saves your recently used, so that you have quick access to them.

ヾ（*⌒ヮ⌒*）ゞ   (╬ಠ益ಠ)  ヽ（´ー｀）┌  ｡･ﾟﾟ･(>д<)･ﾟﾟ･｡  (ʃƪ ˘ ³˘)

With hundreds of different kaomoji, you can quickly send a fun message to your friends, and with the custom mode, you can combine parts to create literally millions of faces in any mood. If you enjoy the emoji keyboard, you will definitely want the Kaomoji Keyboard as a companion to it!