¡Consigue los divertidos Kaomoji, emoticonos japoneses directamente en el teclado de tu iPhone o iPad!

(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧  (╯°□°）╯︵ ┻━┻   (ﾟДﾟ≡ﾟДﾟ)?   (´°̥̥̥̥̥̥̥̥ω°̥̥̥̥̥̥̥̥｀)   （*＾3＾）/～❤

Puedes escribir kaomoji desde cualquier aplicación con este teclado para iOS8. Expresa cualquier emoción con los emoticonos alegres, enfadados, tristes y ligones incluidos, o crea los tuyos propios combinando la boca, ojos y brazos para conseguir tu propia expresión única.

La aplicación del teclado kaomoji viene con una app donde puedes probar el teclado, pero si lo instalas como un teclado del sistema, podrás usar Kaomoji en cualquier aplicación, como por ejemplo Mensajes, WhatsApp o Facebook. También te permite guardar tus favoritos o usar los más recientes para tener acceso rápido a ellos

ヾ（*⌒ヮ⌒*）ゞ   (╬ಠ益ಠ)  ヽ（´ー｀）┌  ｡･ﾟﾟ･(>д<)･ﾟﾟ･｡  (ʃƪ ˘ ³˘)

Con cientos de kaomoji distintos, podrás mandar rápidamente mensajes divertidos a tus amigos, y con el editor podrás combinar distintas partes para crear literalmente millones de caras con cualquier expresión. ¡Si te gusta el teclado de emoticonos, seguramente querrás el Teclado Kaomoji como compañero!